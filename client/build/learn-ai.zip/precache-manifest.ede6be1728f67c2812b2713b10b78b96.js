self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d42d9d1bebbf6c36da16d800e0844351",
    "url": "/index.html"
  },
  {
    "revision": "ef91b74a822478b37cfa",
    "url": "/static/css/2.2c590c31.chunk.css"
  },
  {
    "revision": "cd1e3fb3fff12cdaa7f1",
    "url": "/static/css/main.95b4abf9.chunk.css"
  },
  {
    "revision": "ef91b74a822478b37cfa",
    "url": "/static/js/2.08cac6bb.chunk.js"
  },
  {
    "revision": "0b3bcac8dd197e8a930943c2f484edc4",
    "url": "/static/js/2.08cac6bb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "dfa7fdb8d03ba92990e7",
    "url": "/static/js/3.5efff5dd.chunk.js"
  },
  {
    "revision": "cd1e3fb3fff12cdaa7f1",
    "url": "/static/js/main.0b4f339c.chunk.js"
  },
  {
    "revision": "86d278136e94ca7bd6ee",
    "url": "/static/js/runtime-main.25e93215.js"
  },
  {
    "revision": "ba49e844892321d8540ea3b7c088cf97",
    "url": "/static/media/bootstrap-icons.ba49e844.woff"
  },
  {
    "revision": "cc1e5eda776be5f0ff614285c31d4892",
    "url": "/static/media/bootstrap-icons.cc1e5eda.woff2"
  },
  {
    "revision": "f540a12d889f1ab9ed9a6cee78a03dac",
    "url": "/static/media/person-icon-1.f540a12d.png"
  },
  {
    "revision": "ab8c8e41d769ffc40b87b5d5c993bdad",
    "url": "/static/media/quizapp_logo.ab8c8e41.png"
  }
]);